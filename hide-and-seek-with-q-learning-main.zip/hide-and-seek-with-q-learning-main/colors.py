cyan = (49, 204, 204)
medium_blue = (0, 0, 205)
purple = (128, 0, 128)
grey = (128, 128, 128)

white = (255, 255, 255)

light_purple = (197, 139, 231)
light_green = (144, 238, 144)
forest_green = (34, 139, 34)
red=(255,0,0)
light_red=(255, 150, 150)